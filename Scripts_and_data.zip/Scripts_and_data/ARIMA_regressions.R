# This script executes some statistics describing the frequency of the suitable climatic conditions to the
# species in the past temporal intervals and compare them to the conditions the Ethiopian wolf is experiencing
# now. The main part of this script runs the ARIMA regressions described in the material and methods section
# of the manuscript to test the relationship between the species' geographic range, the temperature and altitude 
# at which the species lived through time. Since this regression include a "time" component, it has to take
# into account the issue of the temporal autocorrelation, which depends on the fact that values measured 
# at consecutive time bin are more similar than values measured at distant temporal intervals. This issue 
# can lead to an imperfect detection of the regression parameters (see metarial and methods for details),
# thus masking true relationships.





# First, clean the workspace!
rm(list=ls(all=TRUE))

# Set the path to the folder including the datasets used in these analyses. The path must end with "/"
path_to_data<-""

# Loading the useful libraries
library(onewaytests)
library(forecast)
library(astsa)
library(lmtest)


# Load the data.frame including the surface area in meters of the species' geographic
# ranges in the considered time frame along with the mean temperature and altitude values sampled
# by the species in its geographic ranges through time

arima_data<-read.table(paste(path_to_data,"arima_data.txt",sep=""),header=TRUE)
arima_data$time_frame=1:2001


#### Some statistics ####
# Computing how may time intervals had climatic conditions worst than that Canis simensis is experiencing now

length(which(arima_data[1,1]>arima_data[-1,1])) # 113 temporal bins with climatic conditions worst than the present
(length(which(arima_data[1,1]>arima_data[-1,1]))/length(arima_data[-1,1]))*100 # the 5.65% only of all the considered time bins (from 0 to 2 Mya) were worst than the present!


# Testing if the variance of species' geographic ranges in the time bins younger than 1 Mya is higher than
# the variance of ranges for time bins older than 1 Mya

# Grouping time bins older or younger than 1 Mya 
arima_data$group<-"A"
arima_data[which(arima_data$time_frame<=1000),"group"]<-"B"

# Plotting the species geographic ranges through time
plot(arima_data$time_frame,arima_data$area,type="l")

# Computing the variance of the species' geographic ranges at bins older than 1 Mya (group A)
# and at bins younger than 1 Mya (group B)
group_var<-aggregate(area~group,data=arima_data,var)

# Is the variance of group A lower than group B?
group_var[1,2]<group_var[2,2]

# Brown-Forsythe statistics to test if the difference in the two variance is statistically significant
# Brown-Forsythe is a test for homogeneity of variance which is more robusto than the Levene test

bf.test(log10(area)~group,arima_data) # the difference is statistically significant!





#### ARIMA regression: Testing the relationships between geographic range, temperature and altitude ####

y<-log10(arima_data$area) # Log10 species geographic range through time
te<-arima_data$mean_temp # mean annual temperature sampled by the species through time 
al<-log10(arima_data$mean_alt) # Log10 mean altitude sampled by the species through time

# OLS model
OLS_model<-lm(y~te+al)

# Autocorrelation function's plot of the OLS model's residuals
acf1(residuals(OLS_model))

# Computing the AR component by Maximum Likelihood estimation (see material and methods for details)
resi.ar <- ar(residuals(OLS_model), method = "mle")
resi.ar$order # order of the AR component


# Calibrating all the ARIMA parameters by MLE
x<-cbind(te,al)
set.seed(1979)
am2_auto=auto.arima(y,xreg=as.matrix(x),trace=TRUE,
                    approximation=FALSE,
                    truncate=NULL)

# Testing manually different ARIMA parameters' combinations
am2_0=arima(y,order=c(resi.ar$order,1,0),xreg=data.frame(x))
am2_1=arima(y,order=c(resi.ar$order,1,1),xreg=data.frame(x))
am2_2=arima(y,order=c(resi.ar$order,1,2),xreg=data.frame(x))
am2_3=arima(y,order=c(resi.ar$order,1,3),xreg=data.frame(x))
am2_4=arima(y,order=c(resi.ar$order,1,4),xreg=data.frame(x))
am2_5=arima(y,order=c(resi.ar$order,1,5),xreg=data.frame(x))

# Selecting the best ARIMA parameters by AIC comparisons
am2_auto$aic
am2_0$aic
am2_1$aic
am2_2$aic
am2_3$aic
am2_4$aic # model 4 parameters are the best!
am2_5$aic



# Plot of ARIMA regression residuals' autocorrelation function
acf1(residuals(OLS_model),max.lag = 2000)->acf_m0
acf1(residuals(am2_auto),max.lag = 2000)->acf_am2_auto
acf1(residuals(am2_0),max.lag = 2000)->acf_am2_0
acf1(residuals(am2_1),max.lag = 2000)->acf_am2_1
acf1(residuals(am2_2),max.lag = 2000)->acf_am2_2
acf1(residuals(am2_3),max.lag = 2000)->acf_am2_3
acf1(residuals(am2_4),max.lag = 2000)->acf_am2_4
acf1(residuals(am2_5),max.lag = 2000)->acf_am2_5


# Plotting the ARIMA model's standardized residuals, the autocorrelation function
# of the residuals, and the p-values of a Portmanteau test for all lags up to gof.lag.
tsdiag(am2_4,gof.lag=2000)

# Extracting the regression's coefficients from the best model
coeftest(am2_4)





