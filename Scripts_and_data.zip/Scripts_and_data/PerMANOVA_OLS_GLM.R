# This script executes the analyses to test the differences between the considered future
# climatic projections provided by the CMIP6 Project and related shared socio-economic pathways (SSPs) in terms 
# measured landscape metrics for the habitat of Canis simensis, and the 
# analyses to test the relationships between Canis simensis Habitat Suitability Index classes (HSI classes) and 
# the landscape metrics and their temporal evolution.
# The future scenarios rely on hypotheses about different strategies mitigating or not mitigating at all
# the current global warming trend. It is important to investigate the fate of Canis simensis under
# these different future climatic projections and to understand if even under more optimistic scenarios
# the species will be threatened in the next future.
# The first analysis is a complication of the common MANOVA but able to deal with skewed data distributions
# and is named PerMANOVA, since it relies on permutations to produce p values. This analysis
# is used to test if the different future scenarios may lead to the same degree of the species' habitat fragmentation
# degree by considering some metrics of the landscape computed under these future conditions.
# In the case statistically differences have been detected, then a second similar test, the Pairwise PerMANOVA, is 
# used to specifically identify the future climate projections yielding results (i.e. species' faith) different from
# all the other models.
# The second set of analyses focuses on detecting the future temporal trend of the surface area of the different HSI classes
# to identify which class will increase its geographic extension through time. This test is performed via Ordinary Least
# Square regression (OLS). Then, a set of Generalized Linear Models (GLMs) is performed to test which of the landscape metrics 
# is a statistically better descriptor of the HSI classes by taking into account the temporal variation of all these variables

# First, clean the workspace!
rm(list=ls(all=TRUE))

# Loading useful libraries
library(vegan)
library(beanplot)
#library(devtools)
#install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
library(pairwiseAdonis)

# Set the path to the folder including the datasets used in these analyses. The path must end with "/"
path_to_data<-"" 

# Loading landscape metrics computed with MIROC6 CMIP6 models and related shared socio-economic pathways (SSPs)
MIROC6_dat<-read.table(paste(path_to_data,"MIROC6.txt",sep=""), header=TRUE)

# Loading landscape metrics computed with BCC-CSM2-MR CMIP6 models and related shared socio-economic pathways (SSPs)
BCC_CSM2_MR_dat<-read.table(paste(path_to_data,"BCC-CSM2-MR.txt",sep=""), header=TRUE)

# Loading landscape metrics computed with CNRM-CM6-1 CMIP6 models and related shared socio-economic pathways (SSPs)
CNRM_CM6_1_dat<-read.table(paste(path_to_data,"CNRM-CM6-1.txt",sep=""), header=TRUE)

# Loading landscape metrics computed with CNRM-ESM2-1 CMIP6 models and related shared socio-economic pathways (SSPs)
CNRM_ESM2_1_dat<-read.table(paste(path_to_data,"CNRM-ESM2-1.txt",sep=""), header=TRUE)



# Combining all the datasets into one single dadaframe
rbind(MIROC6_dat,BCC_CSM2_MR_dat,CNRM_CM6_1_dat,CNRM_ESM2_1_dat)->metric_data
str(metric_data)
# Correcting the format of some features of the landscape
as.numeric(metric_data$layer)->metric_data$layer # "layer" is the temporal interval
as.numeric(metric_data$class)->metric_data$class # "class" represents the HSI classes (see material and methods)

# Removing useless columns
metric_data[,-c(2,4)]->metric_data

# Checking if all the future climatic projections were included in the dataset
metric_data$model

# Setting apart the dataset including estimates of future patches' area equal to zero. Indeed,
# with some future projections, the surface area of some HSI classes (mainly the best ones for the species' survival!)
# will completely disappear. We assigned a very small value of surface areas (0.001 square meters) to these 
# cases of disappeared patch area in order to used them in a Log10 version for specific analyses.
# Unfortunately, these rows with zero area have no other landscape metrics, since they are based on patch's area,
# which is zero in the original dataset. So, we used these cases of null area set to 0.001 in those 
# analyses involving patch's area only, whereas used the original dataset excluding rows with null patch's area and other
# metrics for all the other tests.
metric_data_with_0<-metric_data


# Removing rows with zero patch's area and NULL other landscape metrics
metric_data<-metric_data[complete.cases(metric_data),]

# The HSI class 1, i.e. the class with the worst bioclimatic conditions to the species, is 4 orders
# of magnitude larger that all the other classes, since most of Ethiopia territory is unsuitable
# (in the past, present and future climatic conditions) to the species. This implies that most of the 
# statistical parameters of all the considered analyses are driven by this disproportionate difference
# between classes' patches abundance, even in the Log10 scale, thus masking important relationships.
# As a consequence, we decided to remove from the analyses all the data related to the overabundant 
# HSI class 1.
boxplot(log10(area_mn)~class,data=metric_data)
metric_data<-metric_data[-which(metric_data$class==1),]
as.factor(metric_data$ssp)->metric_data$ssp
as.factor(metric_data$model)->metric_data$model
rownames(metric_data)<-NULL




#### Permanova with repeated measures ####
# Setting the data for the PerMANOVA analysis
# Since any model yield landscape metrics for the same SSPs we are in the case 
# of a MANOVA with repeated measures
metric_data->metric_data_permanova
metric_data_permanova<-metric_data_permanova[complete.cases(metric_data_permanova),]

set.seed(1979)
perm <- how(nperm = 9999) # setting the permutations
setBlocks(perm)<-with(metric_data_permanova, ssp) # setting the levels of the repeated measures
ado_res<-adonis2(log10(metric_data_permanova[,c(3,6,7,8,10)])~model+layer,data=metric_data_permanova,method = "euclidean",permutations = perm)
ado_res


#### Pairwise Permanova with repeated measures ####
# Testing the pairwise differences between climatic projections always with repeated measures
set.seed(1979)
pw_ado_res<-pairwise.adonis2(log10(metric_data_permanova[,c(3,6,7,8,10)])~model+layer,data=metric_data_permanova,strata="ssp",
                             sim.function="vegdist",method = "euclidean",perm = 9999)
pw_ado_res






# Testing the difference between the CMIP6 future projections and related SSPs
# in terms of patch's are only, this time including cases of totally disappeared classes,
# i.e. HSI classes with surface area equal to 0.001 square maters.
beanplot(log10(area_mn)~ssp,data=metric_data, col=list("palegreen","palegoldenrod","sienna1","red3"))

str(metric_data_with_0)
as.character(metric_data_with_0$ssp)->metric_data_with_0$ssp
summary(aov(log10(area_mn)~model+ssp,data=metric_data_with_0))


# Setting the dataset for the OLS and GLM regressions
# Loading the landscape metrics computed with the current climatic conditions
# but with present rasters upscaled to ~4 x ~4 Km cell resolution
current<-read.table(paste(path_to_data,"present_4k.txt",sep=""), header=TRUE)
current<-current[,-c(2,4)]
current[!is.na(current$class),]->current
current<-split(current,current$metric)
lapply(1:length(names(current)), function(i) {
  print(i)
  current[[i]]->new_current
  colnames(new_current)[4]<-names(current)[i]
return(new_current)})->current
do.call(cbind,current)->current
current$model<-"observed"
current$ssp<-"observed"
current<-current[,!duplicated(colnames(current))]
current<-current[,-which(colnames(current)%in%c("metric","area_sd","enn_sd","enn_mn","split"))]
current$layer<-2021
current<-current[,match(colnames(metric_data),colnames(current))]
current<-current[-which(current$class==1),]

#### Reconstructing the HSI classes' surface area temporal trend by means of OLS for each future CMIP6 scenario, separately ####
split(metric_data_with_0,metric_data_with_0$model)->metric_data_with_0_split
summary(lm(log10(area_mn)~layer+class,data=rbind(current,metric_data_with_0_split[[1]]))) # BCC-CSM2-MR 
summary(lm(log10(area_mn)~layer+class,data=rbind(current,metric_data_with_0_split[[2]]))) # CNRM-CM6-1  
summary(lm(log10(area_mn)~layer+class,data=rbind(current,metric_data_with_0_split[[3]]))) # CNRM-ESM2-1
summary(lm(log10(area_mn)~layer+class,data=rbind(current,metric_data_with_0_split[[4]]))) # MIORC6      



#### Detecting the statistically significant landscape descriptors of the HSI classes' temporal evolution by means of GLM regression ####

split(metric_data,metric_data$model)->metric_data_by_model

#### GLM with gamma distribution ####
summary(glm(class~log10(area_mn):layer+ai:layer+clumpy:layer+cohesion:layer+np:layer,data=rbind(current,metric_data_by_model[[1]]),family=Gamma(link="inverse"))) # BCC-CSM2-MR 
summary(glm(class~log10(area_mn):layer+ai:layer+clumpy:layer+cohesion:layer+np:layer,data=rbind(current,metric_data_by_model[[2]]),family=Gamma(link="inverse"))) # CNRM-CM6-1  
summary(glm(class~log10(area_mn):layer+ai:layer+clumpy:layer+cohesion:layer+np:layer,data=rbind(current,metric_data_by_model[[3]]),family=Gamma(link="inverse"))) # CNRM-ESM2-1
summary(glm(class~log10(area_mn):layer+ai:layer+clumpy:layer+cohesion:layer+np:layer,data=rbind(current,metric_data_by_model[[4]]),family=Gamma(link="inverse"))) # MIORC6      


